<template>
  <div class="PIBMAIN010001 aosBoxGroup">
    <section>
      <h2 class="blind">중앙 비주얼 영역</h2>
      <div class="parallax02">
        <div class="img">fade-up</div>
        <!-- <div class="img" data-aos="dd" data-aos-once="false" data-aos-delay="50" data-aos-offset="300" data-aos-duration="3000">fade-up</div> -->
        <div class="scroll">
          <i class="material-icons"> keyboard_arrow_down </i>
        </div>
      </div>
      <br /><br />
      <div class="parallax-container">
        <div class="parallax"><img src="https://materializecss.com/images/parallax1.jpg" /></div>
      </div>
      <br /><br />
      <div class="parallax03">
        <div class="text" data-aos="fade-up">data-aos="fade-up" data-aos-delay="2000" data-aos-offset="0" data-aos-duration="0"</div>
        <div class="text2" data-aos="fade-up">주의! 처음 data-aos-offset="0" 이어야 잘 보임, 아니면 스크롤을 내려야 잘 보임</div>
      </div>
    </section>
    <br /><br />
    <br /><br />
    <!-- js ~ -->
    <section class="sectionJs01">
      <div class="extra-content">
        <p>Parallax Scrolling (JS)</p>
      </div>
      <div class="section">
        <div class="parallax-element background"></div>
        <div class="parallax-element square"></div>
        <div class="parallax-element circle"></div>
        <strong class="parallax-element title">느림의 중요성을 깨달은 달팽이</strong>
      </div>

      <div class="extra-content">
        <p>Parallax Scrolling</p>
      </div>
      <div class="section">
        <div class="parallax-element background"></div>
        <div class="parallax-element square"></div>
        <div class="parallax-element circle"></div>
        <strong class="parallax-element title">그냥 느린 가을이</strong>
      </div>

      <div class="extra-content">
        <p>Parallax Scrolling</p>
      </div>
    </section>
    <br /><br />
    <br /><br />
    <div class="parallax">
      <div class="item1">item1</div>
      <div class="item2">item2</div>
      <div class="item3">item3</div>
      <strong class="title">Parallax Scolling (CSS)</strong>
    </div>
    <!-- 가져오기 -->
    <!--     <section id="slider" class="slider-element slider-parallax swiper_wrapper min-vh-60 min-vh-md-100 include-header">
      <h2 class="blind">중앙 비주얼 영역</h2>
      <div class="slider-inner">
        <div class="swiper-container swiper-parent">
          <div class="swiper-wrapper">
            <div class="swiper-slide dark">
              <div class="container">
                <div class="slider-caption slider-caption-center">
                  <h2 data-aos="fade-Up">Welcome to Canvas</h2>
                  <p class="d-none d-sm-block" data-aos="fade-Up" data-aos-delay="200">Create just what you need for your Perfect Website. Choose from a wide range of Elements &amp; simply put them on your own Canvas.</p>
                </div>
              </div>
              <div class="swiper-slide-bg" style="background-image: url('/src/assets/public/images/vi_slider_swiper_1.jpg')"></div>
            </div>
          </div>
        </div>
      </div>
    </section> -->
  </div>
</template>

<script>
import AOS from 'aos';

export default {
  name: 'AOS',
  data() {
    return {};
  },
  mounted() {
    AOS.init({
      // Area 1
      // offset: 100,
      // delay: 50,
      // duration: 400,
      // easing: 'ease-in-out',
      // once: true,
      // anchorPlacement: 'top-center',
      // Area 2
      duration: 1200, // new2
    });
    //
    window.addEventListener('scroll', function () {
      // 스크롤 이벤트 리스너 등록
      const sections = document.querySelectorAll('.section'); // 모든 섹션을 가져옴

      sections.forEach(function (section) {
        // 각 섹션에 대해 반복
        let bounds = section.getBoundingClientRect(); // 섹션의 위치와 크기 정보를 가져옴
        const background = section.querySelector('.background'); // 배경 요소
        const title = section.querySelector('.title'); // 제목 요소
        const circle = section.querySelector('.circle'); // 원 요소
        const square = section.querySelector('.square'); // 사각형 요소

        if (bounds.top < window.innerHeight && bounds.bottom >= 0) {
          // 섹션이 뷰포트 내에 있을 때
          var scrolled = window.scrollY - section.offsetTop; // 섹션의 시작점에서 스크롤된 거리를 계산
          background.style.transform = `translateY(${scrolled * 0.8}px)`; // 배경을 스크롤 속도의 80%(빠르게)로 이동
          title.style.transform = `translateY(${scrolled * 0.3}px)`; // 제목을 스크롤 속도의 30%(느리게)로 이동
          circle.style.transform = `translate(${scrolled * 0.5}px, ${scrolled * 0.5}px)`; // circle 왼쪽에서 오른쪽으로 이동
          square.style.transform = `translate(${scrolled * -0.5}px)`; // square 오른쪽에서 왼쪽으로 이동
        }
      });
    });
  },
};
</script>

<style lang="scss">
@import '@assets/styles/pages/MAIN/01/PIBMAIN010001.scss';
</style>
