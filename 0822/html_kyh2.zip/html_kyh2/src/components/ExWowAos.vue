<template>
  <div class="aosBoxGroup">
    <!-- 'new aos anim' 일 경우 2 -->
    <section>
      <h2>3-2 / fadeInDown 각종 테스트</h2>
      <h3>예) 1 / data-aos="example-anim3-2" (직접 만들경우)</h3>
      <!--
      * ★★★주의! 믹스인 애니명은 적용 안되고, 옵션을 복사해 직접 넣으면 ( data-aos-delay="2000" )와 함께 적용이 잘 된다
      -->
      <div class="box" data-aos="example-anim3-2" data-aos-delay="0" data-aos-duration="2000">
        <span>'new aos anim' 일 경우<br />주의! 믹스인 애니명은 적용 안되고, 옵션을 복사해 직접 넣으면 ( data-aos-delay="2000" )와 함께 적용이 잘 된다</span>
      </div>
      <br /><br />
      <!--
      * 주의! 처음 data-aos-offset="0" 이어야 잘 보임, 아니면 스크롤을 내려야 잘 보임
       -->
      <h3>예) 2 / data-aos="fade-down</h3>
      <div class="box" data-aos="fade-down" data-aos-delay="0" data-aos-offset="0" data-aos-duration="0">
        <span
          >data-aos="fade-down" data-aos-delay="2000" data-aos-offset="0" data-aos-duration="0" <br />
          주의! 처음 data-aos-offset="0" 이어야 잘 보임, 아니면 스크롤을 내려야 잘 보임</span
        >
      </div>
      <br /><br />

      <h3>예) 3 / animate.css</h3>
      <!-- animate.css
      .animate__faster : 1s / 2
      .animate__slow : 1s * 2
      -->
      <div class="box animate__animated animate__fadeInDown animate__delay-1s __animate__repeat-2 animate__faster">animate__fadeInDown / animate__delay-1s / animate__repeat-2 / animate__faster</div>
    </section>
    <hr />
    <!-- '기본' 일 경우 -->
    <section>
      <h2>1</h2>
      <div class="box" data-aos="fade-in" data-aos-delay="0">'기본' 일 경우</div>
      <br /><br />
      <div class="box" data-aos="fade-up" data-aos-delay="50" data-aos-offset="50">fade-up</div>
      <div class="box" data-aos="fade-up" data-aos-delay="50" data-aos-offset="0">fade-up</div>
      <div class="box" data-aos="fade-up" data-aos-delay="50" data-aos-offset="0">fade-up</div>
    </section>

    <div class="container front_text">
      <h1 class="front_text_pad big_font">Vel distinctio omnis doloremque</h1>
      <img class="image" src="https://c1.staticflickr.com/9/8666/16715164842_6109732f1e_b.jpg" data-aos="fade-left" />
      <img class="image right" src="https://c1.staticflickr.com/2/1813/30123952858_aaaaa7bb92_k.jpg" data-aos="fade-right" />
      <img class="image" src="https://c1.staticflickr.com/2/1818/43273534694_9c2cf3bd0d_k.jpg" data-aos="fade-left" />
    </div>

    <!-- 'data-aos-anchor' 일 경우 -->
    <section>
      <h2>2</h2>
      <div class="box" data-aos="fade-left" data-aos-anchor="#example-anchor" data-aos-offset="100" data-aos-duration="400">'data-aos-anchor' 일 경우</div>
    </section>

    <!-- 'new aos anim' 일 경우 1 -->
    <section>
      <h2>3-1</h2>
      <div class="item">
        <div class="img" data-aos="example-anim3-1" data-aos-once="false" data-aos-offset="0" data-aos-delay="0" data-aos-duration="3000"></div>
        <span>'new aos anim' 일 경우</span>
      </div>
    </section>

    <!-- 'parallax' 일 경우 -->
    <section>
      <h2>4</h2>
      <div class="parallax">
        <div class="img" data-aos-once="false">fade-up</div>
        <div class="scroll">
          <i class="material-icons"> keyboard_arrow_down </i>
        </div>
      </div>
    </section>

    <!-- 'parallax02' 일 경우 -->
    <section>
      <h2>4</h2>
      <div class="parallax02">
        <div class="img" data-aos-once="false">fade-up</div>
        <div class="scroll">
          <i class="material-icons"> keyboard_arrow_down </i>
        </div>
      </div>
    </section>

    <!-- '기타' 일 경우 -->
    <section>
      <h2>5</h2>
      <div class="box" data-aos="zoom-out-up" data-aos-delay="0" data-aos-duration="400"></div>
    </section>
    <!-- <div>
      <button id="btn">click me</button>
    </div> -->
  </div>
</template>

<script>
import AOS from 'aos';

// Area / jquery 사용시 참
// import $ from 'jquery';
/*
// AOS jquery ~

// Hide Header on on scroll down
var didScroll;
var lastScrollTop = 0;
var delta = 5;
var navbarHeight = $('header').outerHeight();

$(window).scroll(function (event) {
  didScroll = true;
});

setInterval(function () {
  if (didScroll) {
    hasScrolled();
    didScroll = false;
  }
}, 250);

function hasScrolled() {
  var st = $(this).scrollTop();

  // Make sure they scroll more than delta
  if (Math.abs(lastScrollTop - st) <= delta) return;

  // If they scrolled down and are past the navbar, add class .nav-up.
  // This is necessary so you never see what is "behind" the navbar.
  if (st > lastScrollTop && st > navbarHeight) {
    // Scroll Down
    $('header').removeClass('nav-down').addClass('nav-up');
  } else {
    // Scroll Up
    if (st - $(window).height() < $(document).height()) {
      $('header').removeClass('nav-up').addClass('nav-down');
    }
  }

  lastScrollTop = st;
} */
// end

export default {
  name: 'AOS',
  data() {
    return {};
  },
  mounted() {
    AOS.init({
      // Area 1
      // offset: 100,
      // delay: 50,
      // duration: 400,
      // easing: 'ease-in-out',
      // once: true,
      // anchorPlacement: 'top-center',
      // Area 2
      duration: 1200, // new2
    });
  },

  // Area / jquery 사용시 참
  // created() {
  //   $('#btn').click(function () {
  //     alert('hi');
  //   });
  // },
};
</script>

<style lang="scss"></style>
