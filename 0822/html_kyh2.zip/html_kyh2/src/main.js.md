/**
 * main.js
 *
 * Bootstraps Vuetify and other plugins then mounts the App`
 */

// wow 방법 1
// import 'animate.css';
// import VueWow from 'vue-wow';

// wow 방법2
import AOS from 'aos';
import 'aos/dist/aos.css'; // You can also use <link> for styles

AOS.init();

// Plugins
import { registerPlugins } from '@/plugins';

// Components
import App from './App.vue';

// Composables
import { createApp } from 'vue';

const app = createApp(App);

registerPlugins(app);

// app.use(VueWow).mount('#app'); // wow 방법 1
app.mount('#app');
