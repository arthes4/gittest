# AOS - custom animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/michalsnik/pen/WxvNvE](https://codepen.io/michalsnik/pen/WxvNvE).

Showcase of AOS plugin, that animates elements on scroll
https://github.com/michalsnik/aos