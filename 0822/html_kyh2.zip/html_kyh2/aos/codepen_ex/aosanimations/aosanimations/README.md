# AOS - animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/michalsnik/pen/WxNdvq](https://codepen.io/michalsnik/pen/WxNdvq).

Showcase of AOS plugin, that animates elements on scroll
https://github.com/michalsnik/aos