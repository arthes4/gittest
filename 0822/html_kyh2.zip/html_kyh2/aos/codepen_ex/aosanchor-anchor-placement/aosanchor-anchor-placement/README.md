# AOS - anchor & anchor-placement

A Pen created on CodePen.io. Original URL: [https://codepen.io/michalsnik/pen/EyxoNm](https://codepen.io/michalsnik/pen/EyxoNm).

Showcase of AOS library that animates elements on scroll - use case of anchor & anchor-placement setting with different easing

https://github.com/michalsnik/aos