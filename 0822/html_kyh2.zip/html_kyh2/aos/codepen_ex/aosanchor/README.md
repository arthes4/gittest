# AOS - anchor

A Pen created on CodePen.io. Original URL: [https://codepen.io/michalsnik/pen/jrOYVO](https://codepen.io/michalsnik/pen/jrOYVO).

Showcase of AOS library that animates elements on scroll - use case of anchor setting.

https://github.com/michalsnik/aos